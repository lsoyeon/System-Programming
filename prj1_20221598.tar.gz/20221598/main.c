#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bitmap.h"
#include "debug.h"
#include "hash.h"
#include "hex_dump.h"
#include "limits.h"
#include "list.h"
#include "round.h"

bool list_less (const struct list_elem *a, const struct list_elem *b, void *aux) {

                            struct list_item *a_item = list_entry (a, struct list_item, elem);
                            struct list_item *b_item = list_entry (b, struct list_item, elem);
                            return  a_item->data < b_item->data;
}
bool hash_less (const struct hash_elem *a, const struct hash_elem *b, void *aux){
    return a->data < b->data;
}
unsigned hash_hash(const struct hash_elem *e, void *aux) {
    return hash_int(e->data); // 여기서는 `hash_int`를 사용하여 int 데이터에 대한 해시 값을 계산
}
void hash_square (struct hash_elem *e, void *aux){
    e->data = e->data * e->data;
}
void hash_triple (struct hash_elem *e, void *aux){
    e->data = e->data * e->data * e->data;
}
void hash_action_clear (struct hash_elem *e, void *aux){
    free(e);
}
struct list* arr[10]={0, };
struct hash* h[10] = {0, };
struct bitmap* b[10];
int main (void)
{
//create list

char input[100];
char input2[100];
char command[30];
int val;
int val2;
int listnum, num1, num2, before, first, last, num;
size_t size, idx=0;
/*printf("%zu", list_size(&list0));
list_push_back(&list0, &item.elem);
*/
while(1) {
    scanf("%s",command);
        
        if (strcmp(command, "create") == 0) {
            char what [10];
            scanf("%s", what);
            if(strcmp(what,"list") ==0 ){
                scanf("%s", input);
                sscanf(input, "list%d", &listnum);
                arr[listnum] = malloc(sizeof(struct list));
                list_init(arr[listnum]);
            } else if (strcmp(what,"hashtable") == 0) {
                scanf("%s", input);
                sscanf(input, "hash%d", &num);
                h[num] = malloc(sizeof(struct hash));
                hash_init(h[num], hash_hash, hash_less, NULL);
            } else {
                scanf("%s %ld",input,&size);
                sscanf(input,"bm%d", &num);
                b[num] = bitmap_create(size);
            }

        } else if (strcmp(command, "dumpdata") == 0) {
            scanf("%s", input);
            if(input[0] == 'l'){ //list
                sscanf(input, "list%d", &listnum);
                struct list_elem *e;
                if(!list_empty(arr[listnum])){
                    for (e = list_begin (arr[listnum]); e != list_end (arr[listnum]); e = list_next (e)) {
                        struct list_item *item = list_entry (e, struct list_item, elem);
                        printf("%d ",item->data);
                    }
                    printf("\n");
                }
            }
            else if(input[0] == 'b'){ //bitmap
                sscanf(input,"bm%d", &num);
                my_dumpdata(b[num]);
            }
            else{ //hashtable
                sscanf(input, "hash%d", &num);
                struct hash_elem *e; 
                int cnt = h[num]->bucket_cnt;
                if(!hash_empty(h[num])){
                    struct hash_iterator i;
                    hash_first (&i, h[num]);
                    while (hash_next (&i)){
                        printf("%d ",hash_cur(&i)->data );
                    }
                    printf("\n");
                }
            }
            
        } else if(strcmp(command, "bitmap_mark") == 0){
            scanf("%s %d",input, &val);
            sscanf(input, "bm%d",&num);
            bitmap_mark(b[num],val);
        } else if(strcmp(command, "bitmap_test") == 0){
            scanf("%s %d",input, &val);
            sscanf(input, "bm%d",&num);
            if( bitmap_test(b[num],val) ) printf("true\n");
            else printf("false\n");
        } else if(strcmp(command, "bitmap_size") == 0){
            scanf("%s",input);
            sscanf(input, "bm%d",&num);
            printf("%ld\n", bitmap_size(b[num]));
        }else if(strcmp(command, "bitmap_all") == 0){
            scanf("%s %d %d",input, &first, &last);
            sscanf(input, "bm%d",&num);
            if( bitmap_all(b[num],first, last)) printf("true\n");
            else printf("false\n");
        } else if(strcmp(command, "bitmap_any") == 0){
            scanf("%s %d %d",input, &first, &last);
            sscanf(input, "bm%d",&num);
            if( bitmap_any(b[num],first, last)) printf("true\n");
            else printf("false\n");
        } else if(strcmp(command, "bitmap_contains") == 0){
            char flag [10];
            scanf("%s %d %d %s",input, &first, &last, flag);
            sscanf(input, "bm%d",&num);
            if(strcmp(flag, "true") ==0 ) {
                if( bitmap_contains(b[num],first, last, true)) printf("true\n");
                else printf("false\n");
            }
            else {
                if( bitmap_contains(b[num],first, last, false)) printf("true\n");
                else printf("false\n");
            }
        } else if(strcmp(command, "bitmap_count") == 0){
            char flag [10];
            scanf("%s %d %d %s",input, &first, &last, flag);
            sscanf(input, "bm%d",&num);
            if(strcmp(flag, "true") ==0 ) printf("%ld\n", bitmap_count(b[num],first, last, true));
            else printf("%ld\n", bitmap_count(b[num],first, last, false));
        } else if(strcmp(command, "bitmap_scan_and_flip") == 0){
            char flag [10];
            scanf("%s %d %d %s",input, &first, &last, flag);
            sscanf(input, "bm%d",&num);
            if(strcmp(flag, "true")==0) printf("%llu\n", (unsigned long long)bitmap_scan_and_flip(b[num], first, last, true));
            else printf("%llu\n", (unsigned long long)bitmap_scan_and_flip(b[num], first, last, false));
        } else if(strcmp(command, "bitmap_scan") == 0){
            char flag [10];
            scanf("%s %d %d %s",input, &first, &last, flag);
            sscanf(input, "bm%d",&num);
            if(strcmp(flag, "true")==0) printf("%llu\n", (unsigned long long)bitmap_scan(b[num],first, last, true));
            else printf("%llu\n",(unsigned long long) bitmap_scan(b[num],first, last, false));


        } else if(strcmp(command, "bitmap_set") == 0){
            char flag [10];
            scanf("%s %d %s",input,&val,flag);
            sscanf(input, "bm%d",&num);
            if(strcmp(flag, "true")==0) bitmap_set(b[num],val, true);
            else  bitmap_set(b[num],val, false);
        } else if(strcmp(command, "bitmap_set_multiple") == 0){
            char flag [10];
            scanf("%s %d %d %s",input,&num1, &num2, flag);
            sscanf(input, "bm%d",&num);
            if(strcmp(flag, "true")==0) bitmap_set_multiple(b[num], num1, num2, true);
            else  bitmap_set_multiple(b[num], num1, num2 ,false);
        }         
        else if(strcmp(command, "bitmap_set_all") == 0){
            char flag [10];
            scanf("%s %s",input,flag);
            sscanf(input, "bm%d",&num);
            if(strcmp(flag, "true")==0) bitmap_set_all(b[num], true);
            else  bitmap_set_all(b[num], false);
        }else if(strcmp(command, "bitmap_dump") == 0){
            scanf("%s",input);
            sscanf(input, "bm%d",&num);
            bitmap_dump(b[num]);
        } else if(strcmp(command, "bitmap_expand") == 0){
            scanf("%s %d",input, &val);
            sscanf(input, "bm%d",&num);
            bitmap_expand(b[num], val);
        } else if(strcmp(command, "bitmap_flip") == 0){
            char flag [10];
            scanf("%s %d",input, &val);
            sscanf(input, "bm%d",&num);
            bitmap_flip(b[num],val);
        } else if(strcmp(command, "bitmap_reset") == 0){
            char flag [10];
            scanf("%s %d",input, &val);
            sscanf(input, "bm%d",&num);
            bitmap_reset(b[num],val);
        }else if(strcmp(command, "bitmap_none") == 0){
            char flag [10];
            scanf("%s %d %d",input, &first, &last);
            sscanf(input, "bm%d",&num);
            if (bitmap_none(b[num],first, last )) printf("true\n");
            else printf("false\n");
        }
        else if(strcmp(command, "hash_insert") == 0){
            scanf("%s %d",input, &val);
            sscanf(input, "hash%d",&num);
            struct hash_elem *elem = malloc(sizeof(struct hash_elem));
            elem->data = val;
            hash_insert(h[num],elem);
        } else if(strcmp(command, "hash_apply") == 0){
            char action[100];
            scanf("%s %s",input, action);
            sscanf(input, "hash%d",&num);
            if(strcmp(action, "square") == 0){
            hash_apply(h[num],hash_square);
            } else if(strcmp(action, "triple") == 0){
                hash_apply(h[num],hash_triple);
            }
        } else if(strcmp(command, "hash_delete") == 0){
            scanf("%s %d",input, &val);
            sscanf(input, "hash%d",&num);
            struct hash_elem *elem = malloc(sizeof(struct hash_elem));
            elem->data = val;
            hash_delete(h[num],elem);
        } else if (strcmp(command, "hash_empty") == 0) {
            scanf("%s", input);
            sscanf(input,"list%d", &listnum);
            if(hash_empty(h[num])) printf("true\n");
            else printf("false\n");   
        } else if(strcmp(command, "hash_size") == 0){
            scanf("%s",input);
            sscanf(input, "hash%d",&num);
            printf("%zu\n", hash_size(h[num]));
        } else if(strcmp(command, "hash_clear") == 0){
            scanf("%s",input);
            sscanf(input, "hash%d",&num);
            hash_clear(h[num], hash_action_clear);
        } else if(strcmp(command, "hash_find") == 0){
            scanf("%s %d",input , &val);
            sscanf(input, "hash%d",&num);
            struct hash_elem *e = malloc(sizeof(struct hash_elem));
            e->data = val;
            struct hash_elem *find = hash_find(h[num], e);
            if(find !=NULL) printf("%d\n", find->data);
        } else if(strcmp(command, "hash_replace") == 0){
            scanf("%s %d",input , &val);
            sscanf(input, "hash%d",&num);
            struct hash_elem *e = malloc(sizeof(struct hash_elem));
            e->data = val;
            struct hash_elem *replaced = hash_replace(h[num], e);
        } else if (strcmp(command, "list_push_front") == 0) {
            scanf("%s", input);
            sscanf(input,"list%d", &listnum);
            scanf("%d", &val);
            struct list_item *item = (struct list_item *)malloc(sizeof(struct list_item));
            item->data = val;
            list_push_front(arr[listnum], &item->elem);
            
        } else if (strcmp(command, "list_push_back") == 0) {
            scanf("%s", input);
            sscanf(input,"list%d", &listnum);
            scanf("%d", &val);
            struct list_item *item = (struct list_item *)malloc(sizeof(struct list_item));
            item->data = val;
            list_push_back(arr[listnum], &item->elem);
            
        } else if (strcmp(command, "list_front") == 0) {
            scanf("%s", input);
            sscanf(input,"list%d", &listnum);
            printf("%d\n", list_entry(list_front(arr[listnum]), struct list_item, elem)->data);
        } else if (strcmp(command, "list_back") == 0) {
            scanf("%s", input);
            sscanf(input,"list%d", &listnum);
            printf("%d\n", list_entry(list_back(arr[listnum]), struct list_item, elem)->data);
        } else if (strcmp(command, "list_pop_back") == 0) {
            scanf("%s", input);
            sscanf(input,"list%d", &listnum);
            struct list_elem *e = list_pop_back(arr[listnum]);
            free(list_entry(e, struct list_item, elem));

        } else if (strcmp(command, "list_pop_front") == 0) {
            scanf("%s", input);
            sscanf(input,"list%d", &listnum);
            struct list_elem *e = list_pop_front(arr[listnum]);
            free(list_entry(e, struct list_item, elem));
            
        } else if (strcmp(command, "delete") == 0) {
            scanf("%s", input);
            if(input[0]=='l'){
                sscanf(input,"list%d", &listnum);
                free(arr[listnum]);
            } else if(input[0] == 'h') {
                sscanf(input, "hash%d", &num);
                free(h[num]);
            } else {
                sscanf(input,"bm%d", &num);
                bitmap_destroy(b[num]);
            }
        } else if (strcmp(command, "quit") == 0) {
            break;
        } else if (strcmp(command, "list_insert_ordered") == 0) {
            scanf("%s", input);
            sscanf(input,"list%d", &listnum);
            scanf("%d", &val);
            struct list_item *item = (struct list_item *)malloc(sizeof(struct list_item));
            item->data = val;
            list_insert_ordered(arr[listnum], &item->elem, list_less, NULL);
        } else if (strcmp(command, "list_insert") == 0) {
            scanf("%s", input);
            sscanf(input,"list%d", &listnum);
            scanf("%d %d", &val, &val2);
            struct list_item *item = (struct list_item *)malloc(sizeof(struct list_item));
            item->data = val2;
            struct list_elem * e = list_begin(arr[listnum]);
            if(val!=0) {
                for(int i = 0 ;i <val ;i++){
                    e = list_next(e);
                }
            }

            list_insert(e, &item->elem);
        } else if(strcmp(command, "list_empty") == 0) {
            scanf("%s", input);
            sscanf(input,"list%d", &listnum);
            if(list_empty(arr[listnum])) printf("true\n");
            else printf("false\n");
        } else if(strcmp(command, "list_size") == 0) {
            scanf("%s", input);
            sscanf(input,"list%d", &listnum);
            printf("%zu\n", list_size(arr[listnum]));
        } else if(strcmp(command, "list_max") == 0) {
            scanf("%s", input);
            sscanf(input,"list%d", &listnum);
            struct list_elem *e = list_max(arr[listnum],list_less, NULL);
            struct list_item *item = list_entry (e, struct list_item, elem);
            printf("%d\n", item->data);
        } else if(strcmp(command, "list_min") == 0) {
            scanf("%s", input);
            sscanf(input,"list%d", &listnum);
            struct list_elem *e = list_min(arr[listnum],list_less, NULL);
            struct list_item *item = list_entry (e, struct list_item, elem);
            printf("%d\n", item->data);
        }  else if(strcmp(command, "list_remove")==0) {
            scanf("%s", input);
            sscanf(input, "list%d", &listnum);
            scanf("%d", &val);
            struct list_elem *e = list_begin(arr[listnum]);
            if( val != 0){
                for(int i = 0 ; i < val ; i++){
                    e = list_next(e);
                }
            }
            list_remove(e);
        } else if(strcmp(command, "list_reverse")==0) {
            scanf("%s", input);
            sscanf(input, "list%d", &listnum);
            list_reverse(arr[listnum]);
        } else if(strcmp(command, "list_shuffle")==0) {
            scanf("%s", input);
            sscanf(input, "list%d", &listnum);
            list_shuffle(arr[listnum]);
        } else if(strcmp(command, "list_sort")==0) {
            scanf("%s", input);
            sscanf(input, "list%d", &listnum);
            list_sort(arr[listnum],list_less, NULL);
        } else if(strcmp(command, "list_splice")==0) {
            scanf("%s %d", input, &before);
            sscanf(input, "list%d", &num1);
            scanf("%s %d %d", input2, &first, &last);
            sscanf(input2, "list%d", &num2);
            struct list_elem * b = list_begin(arr[num1]);
            struct list_elem * f = list_begin(arr[num2]);
            struct list_elem * l = list_begin(arr[num2]);

            if(before != 0)  {
                for(int i = 0 ; i < before ; i ++){
                    b = list_next(b);
                }
            }
            if(first != 0){
                for(int i = 0 ; i < first ; i ++){
                    f = list_next(f);
                }
            }
            if(last != 0){
                for(int i = 0 ; i < last ; i ++){
                    l = list_next(l);
                }
            }
            list_splice(b, f, l);
        } else if(strcmp(command, "list_swap")==0) {
            scanf("%s %d %d", input, &num1, &num2);
            sscanf(input, "list%d", &listnum);
            struct list_elem * f = list_begin(arr[listnum]);
            struct list_elem * l = list_begin(arr[listnum]);

            if(num1 != 0)  {
                for(int i = 0 ; i < num1 ; i ++){
                    f = list_next(f);
                }
            }
            if(num2 != 0){
                for(int i = 0 ; i < num2 ; i ++){
                    l = list_next(l);
                }
            }
            list_swap(f, l);
        } else if(strcmp(command, "list_unique") == 0) {
            scanf("%s", input);
            sscanf(input, "list%d", &num1);
            if(getchar() == '\n'){
                list_unique(arr[num1], NULL, list_less, NULL);
            } else {
                scanf("%s", input2);
                sscanf(input2, "list%d", &num2);
                list_unique(arr[num1], arr[num2], list_less, NULL);
            }
        }
}
return 0;
}